//turns title blue
let title = document.getElementById("title");
function turnBlue (){
  title.style.color = "blue";
}
title.onclick = turnBlue;

//square turns pink
let square = document.getElementById("square");
function turnPink (){
  square.style.backgroundColor = "pink";
}
square.onmouseover = turnPink;

//reveals shape
let squareWord = document.getElementById("squareWord");
function revealSquare(){
  squareWord.innerHTML = "square";
  squareWord.style.textAlign = "center";
}
squareWord.onclick = revealSquare;

//reveals level
let level1 = document.getElementById("level1");
function revealLevel1(){
  level1.innerHTML = "level 1";
  level1.style.textAlign = "center";
}
level1.ondblclick = revealLevel1;

//shape background turns black
let triangle = document.getElementById("triangle")
function turnBlack(){
  triangle.style.backgroundColor = "black";
}
triangle.onmousemove = turnBlack;

//reveals shape
let triangleWord = document.getElementById("triangleWord");
function revealTriangle(){
  triangleWord.innerHTML = "triangle";
  triangleWord.style.textAlign = "center";
}
triangleWord.onwheel = revealTriangle;

//reveals level
let level2 = document.getElementById("level2");
function revealLevel2(){
  level2.innerHTML = "level 2";
  level2.style.textAlign = "center";
}
level2.onclick = revealLevel2;

//shape background turns yellow
let circle = document.getElementById("circle")
function turnYellow(){
  circle.style.backgroundColor = "yellow";
}
document.onkeyup = turnYellow;

//reveals shape
let circleWord = document.getElementById("circleWord");
function revealCircle(){
  circleWord.innerHTML = "circle";
  circleWord.style.textAlign = "center";
}
circleWord.onmouseout = revealCircle;

//reveals level
let level3 = document.getElementById("level3");
function revealLevel3(){
  level3.innerHTML = "level 3";
  level3.style.textAlign = "center";
}
document.onkeydown = revealLevel3;

//winning message
let win = document.getElementById("win");
function winner(){
  win.innerHTML = "You Win ! To play again refresh the page !";
  win.style.textAlign = "center";
  win.style.position = "absolute";
}
document.onclick = winner;